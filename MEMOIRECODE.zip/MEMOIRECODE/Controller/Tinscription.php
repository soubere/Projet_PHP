<?php 
	include('../functions/fonctions.php');  
	include('../classe/Database.php'); 
	include('../classe/Users.php');  

	chargerMesClasses();

	$db = new Database();

	if (isset($_POST['inscription'])) {
		extract($_POST);
		if (notEmpty([$nom, $prenom, $telephone, $profession, $sexe, $email, $identifiant, $mdp])) {

			$user = new Users($nom, $prenom, $telephone, $profession, $sexe, $email, $identifiant, $mdp);

			if($db->addUser($user)){
				header('Location: ../View/Vaccueil.php');
			}else{
				message("Erreur d'ajout");
			}
			
		}
		else{
			message("Veuillez remplir tous les champs");
		}
	}

?>