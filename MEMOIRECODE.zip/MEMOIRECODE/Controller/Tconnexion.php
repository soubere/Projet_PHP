<?php 
session_start();
	
	include('../functions/fonctions.php'); 
	include('../classe/Database.php'); 
	chargerMesClasses();

	$db = new Database();

	if (isset($_POST['connexion'])) {
		extract($_POST);
		if (notEmpty([$identifiant, $mdp])) {
			$data = $db->userExist($identifiant, $mdp);
			if($data){
				$_SESSION['identifiant'] = $data->identifiant;
				//$_SESSION['identifiant'] = $_POST['identifiant'];
				echo '<div class="alert alert-success">connexion avec succee</div><br>';;
					header("Location: ../View/Vpageprofil.php");
					
					exit();
			}else{
				message("Login ou mot de passe incorrect <br>");
			}
		}else{
			message("Veuillez remplir tous les champs<br>");
		}
	}
?>