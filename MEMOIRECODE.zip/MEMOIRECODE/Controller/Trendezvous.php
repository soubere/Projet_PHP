<?php 
	include('../functions/fonctions.php');  
	include('../classe/Database.php'); 
	include('../classe/Rendezvous.php');  


	chargerMesClasses();

	$db = new Database();

	if (isset($_POST['valider'])) {
		extract($_POST);
		if (notEmpty([$nom, $prenom, $telephone, $profession, $sexe, $email])) {

			$rv = new Rendezvous($nom, $prenom, $telephone, $profession, $sexe, $email);

			if($db->addRV($rv)){
				header('Location: ../View/Vaccueil.php');
			}else{
				message("Erreur d'ajout");
			}
			
		}
		else{
			message("Veuillez remplir tous les champs");
		}
	}

?>