<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>MEMOIRE WEB</title>
	<!-- Mobile Specific Metas -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

	<link rel="stylesheet" type="text/css" href="vendors/styles/core.css">
	<link rel="stylesheet" type="text/css" href="vendors/styles/icon-font.min.css">
	<link rel="stylesheet" type="text/css" href="vendors/styles/style.css">
	<script type="text/javascript" src="script/mes_script.js"></script>

</head>
<body>
		<div class="container">
			<div class="row align-items-center">
				<div class="col-md-12 col-lg-7">
					<img src="vendors/images/logoanaxa.png" alt="">
				</div>
				<div class="col-md-6 col-lg-5">
					<div class="login-box bg-white box-shadow border-radius-10">
						<div class="login-title">
							<h2 class="text-center text-primary">FORMULAIRE D'INSCRIPTION</h2>
						</div>
						<form method="post" action="../Controller/Tinscription.php">
							<div class="select-role">
								<div class="btn-group btn-group-toggle" data-toggle="buttons">
									<label class="btn">
										<input type="radio" name="options" id="user">
										<div class="icon"><img src="vendors/images/person.svg" class="svg" alt=""></div>
										utilisateur
									</label>
								</div>
							</div>
							
							<div class="row">
	                            <div class="col-xs-6 col-sm-6 col-md-6">
	                                <div class="input-group custom">
									<input type="text" class="form-control form-control-lg" placeholder="votre nom" name="nom">
	                            	</div>
	                            </div>
	                            <div class="col-xs-6 col-sm-6 col-md-6">
	                                <div class="input-group custom">
									<input type="text" class="form-control form-control-lg" placeholder="votre prenom" name="prenom">
									</div>
	                            </div>
                          	</div>
                          	<div class="row">
	                            <div class="col-xs-6 col-sm-6 col-md-6">
	                                <div class="input-group custom">
									<input type="text" class="form-control form-control-lg" max="9" placeholder="votre telephone" name="telephone">
	                            	</div>
	                            </div>
	                            <div class="col-xs-6 col-sm-6 col-md-6">
	                                <div class="input-group custom">
									<input type="text" class="form-control form-control-lg" placeholder="votre profession" name="profession">
									</div>
	                            </div>
                          	</div>

							<div class="row">
	                            <div class="col-xs-6 col-sm-6 col-md-6">
	                                <div class="input-group custom">
									<input type="text" class="form-control form-control-lg" placeholder="votre sexe" name="sexe">
	                            	</div>
	                            </div>
	                            <div class="col-xs-6 col-sm-6 col-md-6">
	                                <div class="input-group custom">
									<input type="email" class="form-control form-control-lg" placeholder="votre email" name="email">
									</div>
	                            </div>
                          	</div>

                          	<div class="row">
	                            <div class="col-xs-6 col-sm-6 col-md-6">
	                                <div class="input-group custom">
									<input type="text" class="form-control form-control-lg" placeholder="votre identifiant" name="identifiant">
	                            	</div>
	                            </div>
	                            <div class="col-xs-6 col-sm-6 col-md-6">
	                                <div class="input-group custom">
									<input type="password" class="form-control form-control-lg" placeholder="***************" name="mdp">
									</div>
	                            </div>
                          	</div>

							<div class="row pb-30">
								<div class="col-6">
									<div class="custom-control custom-checkbox">
										<input type="checkbox" class="custom-control-input" id="customCheck1">
										<label class="custom-control-label" for="customCheck1">se souvenir</label>
									</div>
								</div>
							</div>

							<div class="row">
								<div class="col-sm-12">
									<div class="input-group mb-0">
										<button class="btn btn-primary btn-lg btn-block" type="submit" name="inscription" id="submit" onclick="return messageuser();">S'inscrire</button>
									</div>
									<div class="font-16 weight-600 pt-10 pb-10 text-center" data-color="#707373"></div>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	<!-- js -->
	<script src="vendors/scripts/core.js"></script>
	<script src="vendors/scripts/script.min.js"></script>
	<script src="vendors/scripts/process.js"></script>
	<script src="vendors/scripts/layout-settings.js"></script>


</body>
</html>