function messageuser(){
	return Alert("Inscription valider avec succee");
}
function confirmation(){
	return confim("Voulez vous reellement valider la demande");
}