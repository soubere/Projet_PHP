<?php
	define("DB_HOST" ,"localhost");
	define("DB_NAME" , "memoire1web");
	define("USER_NAME" , "root");
	define("PWD" , "");
	/**
	 * 
	 */
	class Database
	{
		private $db;
		
		public function __construct($db_host = DB_HOST, $db_name = DB_NAME, $user_name = USER_NAME, $pwd = PWD)
		{
			try {
				$this->db = new PDO("mysql:host=".$db_host.";dbname=".$db_name, $user_name, $pwd);
				$this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			} catch (PDOException $e) {
				die('Erreur'.$e->getMessage());
			}
		}

		public function getDB(){
			return $this->db;
		}

		public function addRV(Rendezvous $rv){
			try {
				$q = $this->getDB()->prepare("INSERT INTO rendezvousw VALUES(null, :nom, :prenom, :telephone, :profession, :sexe, :email)");
				$resultat = $q->execute([
					'nom'=> $rv->getNom(),
					'prenom'=> $rv->getPrenom(),
					'telephone'=> $rv->getTelephone(),
					'profession'=> $rv->getProfession(),
					'sexe'=> $rv->getSexe(),
					'email'=> $rv->getEmail(),
				]);
			} catch (PDOException $e) {
				message("La valeur du champs telephone est déjà existante");
			}

			return $resultat;
		}

		public function addUser(Users $user){
			try {
				$q = $this->getDB()->prepare("INSERT INTO utilisateursw VALUES(null, :nom, :prenom, :telephone, :profession, :sexe, :email, :identifiant, :mdp)");
					$resultat = $q->execute([
					'nom'=> $user->getNom(),
					'prenom'=> $user->getPrenom(),
					'telephone'=> $user->getTelephone(),
					'profession'=> $user->getProfession(),
					'sexe'=> $user->getSexe(),
					'email'=> $user->getEmail(),
					'identifiant'=> $user->getIdentifiant(),
					'mdp'=> $user->getMdp()
				]);
			} catch (PDOException $e) {
				message("La valeur du champs identifiant est déjà existante");
			}

			return $resultat;
		}
	
		
		public function userExist($identifiant, $mdp){
			
			$q = $this->getDB()->prepare('SELECT * from utilisateursw WHERE identifiant = :identifiant AND mdp = :mdp');
				$q->execute([
					'identifiant' => $identifiant,
					'mdp' => $mdp
				]);

				$donnees = $q->fetch(PDO::FETCH_OBJ);

				return $donnees;

		}

		public function addpub(Pubs $pub){
			$q = $this->getDB()->prepare('INSERT INTO pubs VALUES(null, :iduser, :posts, :titre)');
				$resultat = $q->execute([
					'iduser'=> $pub->getIduser(),
					'titre'=> $pub->getTitre(),
					'posts'=> $pub->getPosts()
				]);
			return $resultat;
		}

		public function getAllpub(){
			$q = $this->getDB()->prepare('SELECT pubs.id as id ,identifiant, titre, posts FROM pubs,users
				WHERE pubs.id_user = users.id');
			$q->execute();

			$data = $q->fetchAll(PDO::FETCH_OBJ);

			return $data;
		}

	}
?>