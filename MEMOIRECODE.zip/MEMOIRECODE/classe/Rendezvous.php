<?php 

	/**
	 * 
	 */
	class RendezVous
	{
		private $_nom;
		private $_prenom;
		private $_telephone;
		private $_profesion;
		private $_sexe;
		private $_email;

		function __construct($nom, $prenom, $telephone, $profession, $sexe, $email)
		{
			$this->setNom($nom);
			$this->setPrenom($prenom);
			$this->setTelephone($telephone);
			$this->setProfession($profession);
			$this->setSexe($sexe);
			$this->setEmail($email);

		}

	// LES SETTERS
		public function setNom($nom){$this->_nom = $nom;}
		public function setPrenom($prenom){$this->_prenom = $prenom;}
		public function setTelephone($telephone){$this->_telephone = $telephone;}
		public function setProfession($profession){$this->_profession = $profession;}
		public function setSexe($sexe){$this->_sexe = $sexe;}
		public function setEmail($email){$this->_email = $email;}

	// LES GETTERS
		public function getNom(){return $this->_nom;}
		public function getPrenom(){return $this->_prenom;}
		public function getTelephone(){return $this->_telephone;}
		public function getProfession(){return $this->_profession;}
		public function getSexe(){return $this->_sexe;}
		public function getEmail(){return $this->_email;}
		
	}
	?>