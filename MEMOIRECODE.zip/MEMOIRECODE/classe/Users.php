<?php 

	/**
	 * 
	 */
	class Users
	{
		private $_nom;
		private $_prenom;
		private $_telephone;
		private $_profesion;
		private $_sexe;
		private $_email;
		private $_identifiant;
		private $_mdp;

		
		function __construct($nom, $prenom, $telephone, $profession, $sexe, $email, $identifiant, $mdp)
		{
			$this->setNom($nom);
			$this->setPrenom($prenom);
			$this->setTelephone($telephone);
			$this->setProfession($profession);
			$this->setSexe($sexe);
			$this->setEmail($email);
			$this->setIdentifiant($identifiant);
			$this->setMdp($mdp);
		}

	// LES SETTERS
		public function setNom($nom){$this->_nom = $nom;}
		public function setPrenom($prenom){$this->_prenom = $prenom;}
		public function setTelephone($telephone){$this->_telephone = $telephone;}
		public function setProfession($profession){$this->_profession = $profession;}
		public function setSexe($sexe){$this->_sexe = $sexe;}
		public function setEmail($email){$this->_email = $email;}
		public function setIdentifiant($identifiant){$this->_identifiant = $identifiant;}
		public function setMdp($password){$this->_mdp = $password;}

	// LES GETTERS
		public function getNom(){return $this->_nom;}
		public function getPrenom(){return $this->_prenom;}
		public function getTelephone(){return $this->_telephone;}
		public function getProfession(){return $this->_profession;}
		public function getSexe(){return $this->_sexe;}
		public function getEmail(){return $this->_email;}
		public function getIdentifiant(){return $this->_identifiant;}
		public function getMdp(){return $this->_mdp;}

		
	}
	?>